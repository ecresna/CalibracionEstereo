ns.NumericComparer
ns.StringLogicalComparer

